This dataset was used for the paper: N. Voskarides, D. Odijk, E. Tsagkias, W. Weerkamp, and M. de Rijke.  Query-dependent Contextualization of Streaming Data. In: 36th European Conference on Information Retrieval (ECIR’14).

Statistics :
	- 30 topics, considered 2326 tweets per topic in average, 69789 tweets in total.
	- On average, 2.8 highly relevant and 44.86 relevant concepts per topic.

This package is organized as follows:
	- topics_description.tsv : Brief description of each topic.
	- topics folder : Each subfolder is named after the phrase query used to retrieve the data for the topic followed by the epoch which the topic was detected by our crawler and it contains the following:
		- ‘ids.txt’ : Contains the IDs of the tweets between 2 hours before and 3 hours after the topic was detected trending.
		- ‘goldEntities.txt’ : Contains the relevant concepts of the topic. Highly relevant concepts are denoted as 2 and relevant topics are denoted as 1.

If you have any questions, please send an e-mail to n.voskarides AT uva.nl.